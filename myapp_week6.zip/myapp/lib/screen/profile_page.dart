import 'package:flutter/material.dart';
import '../widgets/profile_header.dart';
import '../widgets/profile_stats.dart';
import '../widgets/action_buttons.dart';
import '../widgets/post_grid.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black, size: 20),
          onPressed: () {},
        ),
        title: const Text(
          'patipan_dev',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.more_horiz, color: Colors.black),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            // ส่วนหัวโปรไฟล์ (Avatar + ชื่อ + Bio) และสถิติ (Posts / Followers / Following)
            ProfileHeader(),
            SizedBox(height: 12),
            // สถิติผู้ใช้งาน (แสดงแถวสถิติตามโครงสร้าง UI Composition)
            ProfileStats(),
            SizedBox(height: 14),
            // ปุ่มกด Follow / Message / Contact
            ActionButtons(),
            SizedBox(height: 12),
            // แถบเมนูเลือกดูโพสต์และตารางโพสต์ (GridView.count)
            PostGrid(),
          ],
        ),
      ),
    );
  }
}