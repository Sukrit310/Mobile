import 'package:flutter/material.dart';

class TrafficLightScreen extends StatefulWidget {
  const TrafficLightScreen({super.key});

  @override
  State<TrafficLightScreen> createState() => _TrafficLightScreenState();
}

class _TrafficLightScreenState extends State<TrafficLightScreen> {
  // สถานะของไฟจราจร: 0 = ไฟแดง, 1 = ไฟเหลือง, 2 = ไฟเขียว
  int _currentLight = 0;

  // ฟังก์ชันเปลี่ยนสถานะไฟแบบวนลูป (0 -> 1 -> 2 -> 0)
  void _changeLight() {
    setState(() {
      _currentLight = (_currentLight + 1) % 3;
    });
  }

  // สร้างดวงไฟแต่ละดวงพร้อม AnimatedOpacity
  Widget _buildLight({required Color color, required bool isActive}) {
    return AnimatedOpacity(
      opacity: isActive ? 1.0 : 0.3,
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeInOut,
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.6),
              blurRadius: 16,
              spreadRadius: 4,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF7E57C2),
        centerTitle: true,
        title: const Text(
          'Traffic Light Animation',
          style: TextStyle(
            color: Colors.black87,
            fontSize: 20,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // ไฟแดง
            _buildLight(
              color: Colors.red,
              isActive: _currentLight == 0,
            ),
            const SizedBox(height: 20),
            // ไฟเหลือง
            _buildLight(
              color: Colors.amber,
              isActive: _currentLight == 1,
            ),
            const SizedBox(height: 20),
            // ไฟเขียว
            _buildLight(
              color: Colors.green,
              isActive: _currentLight == 2,
            ),
            const SizedBox(height: 36),
            // ปุ่มกดเปลี่ยนไฟ
            ElevatedButton(
              onPressed: _changeLight,
              child: const Text('เปลี่ยนไฟ'),
            ),
          ],
        ),
      ),
    );
  }
}