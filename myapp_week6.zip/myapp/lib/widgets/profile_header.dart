import 'package:flutter/material.dart';

class ProfileHeader extends StatelessWidget {
  const ProfileHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // รูปโปรไฟล์ (Avatar)
          const CircleAvatar(
            radius: 42,
            backgroundColor: Color(0xFFE0E0E0),
            backgroundImage: NetworkImage('https://picsum.photos/id/1005/200/200'),
          ),
          const SizedBox(width: 16),
          // ข้อมูลชื่อและคำอธิบายโปรไฟล์ (Bio)
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text(
                  'Patipan Dev',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                    color: Colors.black,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Flutter Developer | Traveler 🌴 | Sushi Lover 🍣',
                  style: TextStyle(
                    fontSize: 13.5,
                    color: Colors.black87,
                    height: 1.3,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'Patipan_dev',
                  style: TextStyle(
                    fontSize: 13.5,
                    color: Color(0xFF00376B),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}