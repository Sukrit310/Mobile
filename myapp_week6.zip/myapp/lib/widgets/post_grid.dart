import 'package:flutter/material.dart';

class PostGrid extends StatelessWidget {
  const PostGrid({super.key});

  // รายการรูปภาพจำลองสำหรับแสดงในตารางโพสต์
  static const List<String> postImages = [
    'https://picsum.photos/id/1005/400/400',
    'https://picsum.photos/id/1015/400/400',
    'https://picsum.photos/id/1016/400/400',
    'https://picsum.photos/id/1025/400/400',
    'https://picsum.photos/id/1035/400/400',
    'https://picsum.photos/id/1040/400/400',
    'https://picsum.photos/id/1043/400/400',
    'https://picsum.photos/id/1050/400/400',
    'https://picsum.photos/id/1060/400/400',
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // แถบไอคอนสลับมุมมองโพสต์ (Grid / Reels / Tagged)
        Container(
          decoration: const BoxDecoration(
            border: Border(
              top: BorderSide(color: Color(0xFFDBDBDB), width: 0.5),
              bottom: BorderSide(color: Color(0xFFDBDBDB), width: 0.5),
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  decoration: const BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: Colors.black, width: 1.5),
                    ),
                  ),
                  child: const Icon(Icons.grid_on, color: Colors.black, size: 24),
                ),
              ),
              const Expanded(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 10),
                  child: Icon(Icons.smart_display_outlined, color: Colors.grey, size: 24),
                ),
              ),
              const Expanded(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 10),
                  child: Icon(Icons.assignment_ind_outlined, color: Colors.grey, size: 24),
                ),
              ),
            ],
          ),
        ),
        // ตารางโพสต์ 3 คอลัมน์โดยใช้ GridView.count ตาม Hint ในโจทย์
        GridView.count(
          crossAxisCount: 3,
          crossAxisSpacing: 2,
          mainAxisSpacing: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: postImages.map((imageUrl) {
            return Image.network(
              imageUrl,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  color: Colors.grey.shade300,
                  child: const Icon(Icons.image, color: Colors.grey),
                );
              },
            );
          }).toList(),
        ),
      ],
    );
  }
}